# Update 2026-07-28 (v1)

using namespace System.Net

# Input bindings are passed in via param block.
param($Timer)

Import-Module Microsoft.Graph.Authentication  -ErrorAction Stop
Import-Module Microsoft.Graph.Sites           -ErrorAction Stop
Import-Module Microsoft.Graph.Users           -ErrorAction Stop
Import-Module Microsoft.Graph.Users.Actions   -ErrorAction Stop
Import-Module Microsoft.Graph.Groups          -ErrorAction Stop
Import-Module ExchangeOnlineManagement        -ErrorAction Stop

$tenantId = $env:TenantId
$clientId = $env:ClientId
$thumbprint = $env:CertificateThumbPrint
$rootSiteUrl = $env:RootSiteUrl
$organization = $env:Organization

# Status
$StatusNew = "New"
$StatusProgress = "In progress"
$StatusDone = "Done"
$StatusError = "Error"

function Find-PartialMatch {
    param (
        $Array,
        $Substring
    )

    foreach ($Item in $Array) {
        if ($Item -like "*$Substring*") {
            return $true
        }
    }

    return $false
}

function Get-MngmntScriptSharepointIds {

    $Site = Get-MgSite -SiteId "root:/sites/coopera" -Property "id"
    $QueryUri = "https://graph.microsoft.com/v1.0/sites/$($Site.Id)/lists?" + '$select=id&$filter=displayName eq ' + "'SolicitudesAdministracion'"
    $List = Invoke-MgGraphRequest -Method GET -Uri $QueryUri


    return [PSCustomObject]@{
        SiteId = $Site.Id
        ListId = $List.values[0].Id
    }
}

function Get-MngmntScriptFilteredList {
    param (
        $Operation,
        $SiteId,
        $ListId
    )
    [array]$ListItems = Get-MgSiteListItem -ListId $ListId -SiteId $SiteId -ExpandProperty "fields(`$select=id,UpnPeticion,OrganoPeticion,OperacionPeticion,ParametrosPeticion,EstadoPeticion,Modified)" -All
    $ItemData = $ListItems.fields | Where-Object {
        $_.AdditionalProperties.OperacionPeticion -eq $Operation -and
        ![string]::IsNullOrEmpty($_.AdditionalProperties.UpnPeticion) -and
        ![string]::IsNullOrEmpty($_.AdditionalProperties.OrganoPeticion) -and
        ($_.AdditionalProperties.EstadoPeticion -eq $StatusNew -or 
        $_.AdditionalProperties.EstadoPeticion -eq $StatusError -or 
         ($_.AdditionalProperties.EstadoPeticion -eq $StatusProgress -and 
        [DateTime]::Parse($_.AdditionalProperties.Modified) -le (Get-Date).AddMinutes(-10)))
    } | ForEach-Object {
        [PSCustomObject]@{
            Id         = $_.Id
            Upn        = $_.AdditionalProperties.UpnPeticion
            Body       = $_.AdditionalProperties.OrganoPeticion
            Operation  = $_.AdditionalProperties.OperacionPeticion
            Parameters = $_.AdditionalProperties.ParametrosPeticion | ConvertFrom-Json
            Status     = $_.AdditionalProperties.EstadoPeticion
            Modified   = [DateTime]::Parse($_.AdditionalProperties.Modified)
        }
    }
    return $ItemData | Sort-Object -Property Id
}

function Update-MngmntScriptItemStatus {
    param (
        $Id,
        $NewStatus,
        $ListId,
        $SiteId
    )

    $FieldsToUpdate = @{
        EstadoPeticion = $NewStatus
    }

    try {
        Update-MgSiteListItemField -SiteId $SiteId -ListId $ListId -ListItemId $Id -BodyParameter $FieldsToUpdate -Confirm:$false -Debug
    }
    catch {
        throw "Error updating item with ID = $Id in SharePoint list"
    }
}

function Remove-MngmntScriptRole {
    param (
        $ItemListId,
        $BodyId,
        $User
    )

    Get-MgUserTransitiveMemberOf -UserId $User.Id -Top 999 | Where-Object { $_.AdditionalProperties["displayName"] -like "$($BodyId)_*" } | ForEach-Object {
        $CurrentGroup = $_
        try {
            Remove-DistributionGroupMember -Confirm:$false  -Identity $CurrentGroup.Id -Member $User.Id -BypassSecurityGroupManagerCheck -ErrorAction Stop
        }
        catch {
            throw "Unable to remove the member $($User.UserPrincipalName) from the group $($CurrentGroup.AdditionalProperties["displayName"])"
        }
    }

    $NumberOfGroups = 0;
    do {
        $GraphGroups = Get-MgUserTransitiveMemberOf -UserId $User.Id -Top 999 | Where-Object { $_.AdditionalProperties["displayName"] -like "$($BodyId)_*" }
        $NumberOfGroups = $GraphGroups.Count
        if ($NumberOfGroups -ne 0) {
            Start-Sleep -Seconds 5
        }
    } while ($NumberOfGroups -ne 0)
}

function Set-MngmntScriptRole {
    param (
        $User,
        $BodyId,
        $Role
    )

    $Bodies = @("$($BodyId)_$Role")

    if ($Role -eq "convocantes") {
        $Bodies += "$($BodyId)_miembros"
    }

    foreach ($CurrentBody in $Bodies) {
        $Group = Get-MgGroup -Filter "displayName eq '$CurrentBody'"
        try {
            Add-DistributionGroupMember -Identity $Group.Id -Member $User.Id -BypassSecurityGroupManagerCheck -ErrorAction Stop
        }
        catch {
            throw "Unable to add the member $($User.UserPrincipalName) to the group $CurrentBody"
        }
    }

    $AllContained = $false
    do {
        $GraphGroups = Get-MgUserTransitiveMemberOf -UserId $User.Id | ForEach-Object { $_.AdditionalProperties["displayName"] }
        $AllContained = ($Bodies | Where-Object { $GraphGroups -contains $_ }).Count -eq $Bodies.Count
        if ($AllContained -eq $false) {
            Start-Sleep -Seconds 5
        }
    } while ($AllContained -eq $false)
}

function Revoke-MngmntScriptLicense {
    param (
        $Upn,
        $UserId
    )
    try {
        $Licenses = Get-MgUserLicenseDetail -UserId $UserId | Where-Object { $_.SkuPartNumber -eq "SPE_E3" -or $_.SkuPartNumber -eq "SPE_E5" }

        foreach ($License in $Licenses) {
            Set-MgUserLicense -UserId $UserId -RemoveLicenses @($License.SkuId) -AddLicenses @{}
        }
    }
    catch {
        throw "Error trying to revoke the assigned licesnse to the user $Upn"
    }
    
}

function Update-MngmntScriptUserLicenses {
    param (
        $User,
        $Body,
        $Role
    )

    try {
        $NewUserType = ""
        $QueryUri = "https://graph.microsoft.com/v1.0/users/$($User.Id)/memberOf?`$select=displayName"
        $Items = Invoke-MgGraphRequest -Method GET -Uri $QueryUri
        $GroupNames = $Items.value | ForEach-Object { $_.displayName }
        if ([string]::IsNullOrEmpty($Role)) {
            $GroupNames = $GroupNames | Where-Object { -not ($_ -contains $Body) }
        }
        else {
            $GroupNames += $Body + "_" + $Role

            if ($Role -eq "convocantes") {
                $GroupNames += $Body + "_miembros"
            }
        }

        if ($GroupNames -eq 0) {
            $NewUserType = "Guest"
        }
        else {
            if ((Find-PartialMatch -Array $GroupNames -Substring "_convocantes") -or (Find-PartialMatch -Array $GroupNames -Substring "_gestorconvocantes")) {
                $NewUserType = "Member"
            }
            else {
                Revoke-MngmntScriptLicense -Upn $User.UserPrincipalName -UserId $User.Id
                $NewUserType = "Guest"
            }
        }

        Update-MgUser -UserId $User.Id -UserType $NewUserType
    }
    catch {
        throw "Error trying to update user's information $($User.UserPrincipalName)"
    }
}

function Update-MngmntScriptTeamsMembership {
    param (
        $User,
        $BodyId,
        $Role,
        $SiteId,
        $TeamId
    )

    try {
        $QueryUri = "https://graph.microsoft.com/v1.0/teams/$TeamId/members"
        $TeamMembers = Invoke-MgGraphRequest -Method GET -Uri $QueryUri
        $TeamUser = $TeamMembers.value | Where-Object { $_.userId -eq $User.Id }

        $IsOwner = $null -ne $TeamUser -and $TeamUser.roles[0] -eq "owner"
        $IsMember = $null -ne $TeamUser -and ([string]::IsNullOrEmpty($TeamUser.roles[0]))
        $IsGuest = $null -ne $TeamUser -and $TeamUser.roles[0] -eq "guest"
        $IsAdminRole = ($Role -in @("convocantes", "gestorconvocantes"))

        if ([string]::IsNullOrEmpty($TeamId)) {
            Write-Error "Body has not configured Teams ID"
            return
        }

        if ([string]::IsNullOrEmpty($Role)) {
            if ($null -ne $TeamUser) {
                # Eliminar al usuario del equipo
                if ($IsOwner) {
                    Remove-UnifiedGroupLinks -Identity $TeamId -LinkType Owners -Links $TeamUser.userId -Confirm:$false -ErrorAction Stop
                }

                try {
                    Remove-UnifiedGroupLinks -Identity $TeamId -LinkType Members -Links $TeamUser.userId -Confirm:$false -ErrorAction Stop
                }
                catch {
                    Write-Information "Removing membership from user $($User.UserPrincipalName) was not possible"
                }         
            }
        }
        else {
            # Agregar o actualizar el rol en Teams
            # El usuario es nuevo en Teams
            if ($null -eq $TeamUser) {
                Add-UnifiedGroupLinks -Identity $TeamId -LinkType Members -Links $User.Id -Confirm:$false -ErrorAction Stop
                if ($IsAdminRole) {
                    Add-UnifiedGroupLinks -Identity $TeamId -LinkType Owners -Links $User.Id -Confirm:$false -ErrorAction Stop
                }
            
                return
            }
            else {
                # Si ya tiene los permisos de Teams de su rol o de uno equivalente, no se hace nada
                # if (($IsOwner -and $IsAdminRole) -or ($IsMember -and -not $IsAdminRole)) {
                #     return
                # }

                # Si cambia de rol a uno inferior: se elimina owner
                if ($IsOwner -and -not $IsAdminRole) {
                    Remove-UnifiedGroupLinks -Identity $TeamId -LinkType Owners -Links $TeamUser.userId -Confirm:$false -ErrorAction Stop
                    return
                }

                # Si cambia de rol a uno superior: ya era guest o member, se añade owner
                if (($IsMember -or $IsGuest) -and $IsAdminRole) {
                    # Hay que hacer la consulta a Graph hasta que nos devuelva que ya es member
                    if ($IsGuest) {
                        $IsMemberYet = $false
                        do {
                            $QueryUri = "https://graph.microsoft.com/v1.0/teams/$TeamId/members"
                            $TeamMembers = Invoke-MgGraphRequest -Method GET -Uri $QueryUri
                            $TeamUser = $TeamMembers.value | Where-Object { $_.userId -eq $User.Id }
                            $IsMemberYet = $null -ne $TeamUser -and ([string]::IsNullOrEmpty($TeamUser.roles[0]))
                            if (-not $IsMemberYet) {
                                Start-Sleep -Seconds 10
                            }
                        } while ($IsMemberYet -eq $false)
                    }                
                    Add-UnifiedGroupLinks -Identity $TeamId -LinkType Owners -Links $User.Id -Confirm:$false -ErrorAction Stop
                }
            }
        }
    }
    catch {
        throw "Error trying to assign user to a Teams team"
    }
}

function Grant-MngmntScriptRoles {
    Connect-MgGraph -NoWelcome -ClientId $clientId -TenantId $tenantId -CertificateThumbprint $thumbprint
    Connect-ExchangeOnline -AppId $clientId -CertificateThumbprint $thumbprint -Organization $organization -ShowBanner:$false
    $SharePointIds = Get-MngmntScriptSharepointIds
    $FilteredList = Get-MngmntScriptFilteredList -Operation "rolemngmnt" -SiteId $SharePointIds.SiteId -ListId $SharePointIds.ListId
    foreach ($Item in $FilteredList) {
        try {
            $CurrentUser = Get-MgUser -UserId $Item.Upn
            if ($null -eq $CurrentUser) {
                throw "Error updating role for item with ID = $($Item.Id). It was not possible to get the user with the UPN '$($Item.Upn)'"
            }
            Update-MngmntScriptItemStatus -Id $Item.Id -NewStatus $StatusProgress -SiteId $SharePointIds.SiteId -ListId $SharePointIds.ListId

            Remove-MngmntScriptRole -ItemListId $Item.Id -BodyId $Item.Body -User $CurrentUser
            if (![string]::IsNullOrEmpty(([string]$Item.Parameters.role).Trim())) {
                Set-MngmntScriptRole -User $CurrentUser -BodyId $Item.Body -Role $Item.Parameters.role 
            }
            Update-MngmntScriptUserLicenses -User $CurrentUser -Body $Item.Body -Role $Item.Parameters.role

            Update-MngmntScriptTeamsMembership -User $CurrentUser -BodyId $Item.Body -Role $Item.Parameters.role -SiteId $SharePointIds.SiteId -TeamId $Item.Parameters.teamId

            Update-MngmntScriptItemStatus -Id $Item.Id -NewStatus $StatusDone -SiteId $SharePointIds.SiteId -ListId $SharePointIds.ListId
        }
        catch {
            Update-MngmntScriptItemStatus -Id $Item.Id -NewStatus $StatusError -SiteId $SharePointIds.SiteId -ListId $SharePointIds.ListId
            Write-Error "An error ocurred trying to process row with ID = $($Item.Id): $($_.Exception.Message)"
        }
        
    }
    Disconnect-MgGraph
    Disconnect-ExchangeOnline -Confirm:$false
}

Grant-MngmntScriptRoles